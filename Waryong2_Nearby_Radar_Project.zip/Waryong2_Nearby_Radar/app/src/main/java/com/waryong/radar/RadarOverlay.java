package com.waryong.radar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Draws highlights over text recognized in the actual captured screen image. */
public class RadarOverlay extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<RectF> detections = new ArrayList<>();
    private int screenshotWidth = 1;
    private int screenshotHeight = 1;
    private boolean enabled = true;

    public RadarOverlay(Context context) {
        super(context);
        setWillNotDraw(false);
        paint.setColor(Color.rgb(73, 250, 151));
        paint.setStrokeWidth(dp(2.4f));
        paint.setStyle(Paint.Style.STROKE);
        background.setColor(0x2249FA97);
        background.setStyle(Paint.Style.FILL);
    }

    private float dp(float v) { return getResources().getDisplayMetrics().density * v; }

    public synchronized void update(List<RectF> boxes, int sourceW, int sourceH) {
        detections = new ArrayList<>(boxes);
        screenshotWidth = Math.max(1, sourceW);
        screenshotHeight = Math.max(1, sourceH);
        invalidate();
    }

    public synchronized void setEnabled(boolean enabled) {
        this.enabled = enabled;
        invalidate();
    }

    @Override protected synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!enabled || screenshotWidth <= 0 || screenshotHeight <= 0) return;
        float scaleX = getWidth() / (float)screenshotWidth;
        float scaleY = getHeight() / (float)screenshotHeight;
        for (RectF r : detections) {
            RectF visible = new RectF(r.left*scaleX, r.top*scaleY,
                    r.right*scaleX, r.bottom*scaleY);
            visible.inset(-dp(7), -dp(5));
            canvas.drawRoundRect(visible, dp(9), dp(9), background);
            canvas.drawRoundRect(visible, dp(9), dp(9), paint);
            // Small pointer directly above the detected name.
            float mid = visible.centerX();
            float top = visible.top;
            canvas.drawLine(mid, top - dp(12), mid, top - dp(3), paint);
            canvas.drawLine(mid-dp(5), top-dp(8), mid, top-dp(3), paint);
            canvas.drawLine(mid+dp(5), top-dp(8), mid, top-dp(3), paint);
        }
    }
}
