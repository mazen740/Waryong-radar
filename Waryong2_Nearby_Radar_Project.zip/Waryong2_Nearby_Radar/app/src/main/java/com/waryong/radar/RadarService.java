package com.waryong.radar;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.text.TextRecognizer;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Detects only text rendered on the screen. It cannot read the Waryong2 engine,
 * game memory, or locations of enemies which are not visible on the device.
 */
public class RadarService extends Service {
    public static final String ACTION_START = "com.waryong.radar.START";
    public static final String ACTION_STOP = "com.waryong.radar.STOP";
    public static final String EXTRA_RESULT = "capture_result";
    public static final String EXTRA_DATA = "capture_data";
    public static final String EXTRA_TARGET = "target";
    private static final int NOTIFICATION_ID = 741;
    private static final String CHANNEL_ID = "radar_screen_capture";
    private static final long INTERVAL_MS = 1400;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private long lastScan = 0;
    private String target = "metin";
    private boolean paused = false;
    private boolean shuttingDown = false;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread worker;
    private Handler background;
    private WindowManager windows;
    private WindowManager.LayoutParams bubbleParams;
    private TextView bubble;
    private RadarOverlay radarLayer;
    private TextRecognizer recognizer;
    private int displayWidth, displayHeight, displayDpi;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        windows = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        worker = new HandlerThread("radar-capture");
        worker.start();
        background = new Handler(worker.getLooper());
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!ACTION_START.equals(intent.getAction())) return START_NOT_STICKY;
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        target = normalize(intent.getStringExtra(EXTRA_TARGET));
        if (target.isEmpty()) target = "metin";
        if (projection != null) { stopCapture(); }

        try {
            Notification notification = createNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            @SuppressWarnings("deprecation")
            Intent resultData = (Intent)intent.getParcelableExtra(EXTRA_DATA);
            int resultCode = intent.getIntExtra(EXTRA_RESULT, 0);
            if (resultData == null || resultCode == 0) throw new IllegalStateException("No consent token");
            MediaProjectionManager manager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = manager.getMediaProjection(resultCode, resultData);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() {
                    mainHandler.post(() -> stopSelf());
                }
            }, mainHandler);
            createOverlays();
            startCapture();
        } catch (Exception e) {
            android.util.Log.e("NearbyRadar", "Cannot start scanner", e);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Nearby scanner screen capture", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Indicates the local on-screen scanner is active");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification createNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 9, open, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("Waryong2 Nearby Scanner")
                .setContentText("On-device screen recognition active")
                .setContentIntent(pi)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    private void createOverlays() {
        if (radarLayer != null) return;
        radarLayer = new RadarOverlay(this);
        WindowManager.LayoutParams drawing = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        drawing.gravity = Gravity.TOP | Gravity.START;
        windows.addView(radarLayer, drawing);

        bubble = new TextView(this);
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(13);
        bubble.setGravity(Gravity.CENTER);
        bubble.setPadding(dp(12), dp(5), dp(12), dp(5));
        bubble.setText("RADAR: 0");
        bubble.setBackgroundColor(0xDA112C35);
        bubbleParams = new WindowManager.LayoutParams(
                dp(115), dp(44), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = dp(18);
        bubbleParams.y = dp(105);
        windows.addView(bubble, bubbleParams);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX, startY;
            private float touchX, touchY;
            private boolean moved;
            private long pressStarted;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = bubbleParams.x; startY = bubbleParams.y;
                        touchX = event.getRawX(); touchY = event.getRawY();
                        moved = false;
                        pressStarted = SystemClock.uptimeMillis();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int)(event.getRawX()-touchX);
                        int dy = (int)(event.getRawY()-touchY);
                        if (Math.abs(dx)+Math.abs(dy) > dp(8)) moved = true;
                        bubbleParams.x = Math.max(0, startX+dx);
                        bubbleParams.y = Math.max(0, startY+dy);
                        windows.updateViewLayout(bubble,bubbleParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved && SystemClock.uptimeMillis() - pressStarted > 750) {
                            stopSelf();
                            return true;
                        }
                        if (!moved) {
                            paused = !paused;
                            radarLayer.setEnabled(!paused);
                            bubble.setText(paused ? "PAUSED" : "RADAR: 0");
                        }
                        return true;
                    default: return false;
                }
            }
        });
    }

    private void updateDisplay() {
        DisplayMetrics metrics = new DisplayMetrics();
        windows.getDefaultDisplay().getRealMetrics(metrics);
        displayWidth = metrics.widthPixels;
        displayHeight = metrics.heightPixels;
        displayDpi = metrics.densityDpi;
    }

    private void startCapture() {
        updateDisplay();
        reader = ImageReader.newInstance(displayWidth, displayHeight, PixelFormat.RGBA_8888, 2);
        reader.setOnImageAvailableListener(this::onFrameAvailable, background);
        virtualDisplay = projection.createVirtualDisplay("Waryong2 Nearby OCR",
                displayWidth, displayHeight, displayDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, background);
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // Android 14+ allows one createVirtualDisplay per permission token.
        // Resize the same display instead of attempting a second creation.
        if (virtualDisplay == null || projection == null) return;
        mainHandler.postDelayed(() -> {
            if (virtualDisplay == null || shuttingDown) return;
            try {
                updateDisplay();
                ImageReader newer = ImageReader.newInstance(displayWidth, displayHeight,
                        PixelFormat.RGBA_8888, 2);
                newer.setOnImageAvailableListener(this::onFrameAvailable, background);
                virtualDisplay.setSurface(newer.getSurface());
                virtualDisplay.resize(displayWidth, displayHeight, displayDpi);
                ImageReader old = reader;
                reader = newer;
                if (old != null) background.postDelayed(old::close, 1000);
            } catch (RuntimeException e) {
                android.util.Log.w("NearbyRadar", "Rotation resize failed", e);
            }
        }, 350);
    }

    private void onFrameAvailable(ImageReader source) {
        Image image = null;
        try {
            image = source.acquireLatestImage();
            if (image == null || paused || shuttingDown) return;
            long now = SystemClock.uptimeMillis();
            if (now - lastScan < INTERVAL_MS || !processing.compareAndSet(false, true)) return;
            lastScan = now;
            Bitmap frame = extractBitmap(image);
            if (frame == null) { processing.set(false); return; }
            Bitmap smaller = frame;
            if (frame.getWidth() > 1200) {
                float ratio = 1200f / frame.getWidth();
                smaller = Bitmap.createScaledBitmap(frame, 1200,
                        Math.max(1, Math.round(frame.getHeight()*ratio)), true);
                frame.recycle();
            }
            final Bitmap scanBitmap = smaller;
            final int w = scanBitmap.getWidth(), h = scanBitmap.getHeight();
            recognizer.process(InputImage.fromBitmap(scanBitmap, 0))
                    .addOnSuccessListener(result -> showMatches(result,w,h))
                    .addOnFailureListener(e -> android.util.Log.w("NearbyRadar", "OCR failed", e))
                    .addOnCompleteListener(task -> {
                        scanBitmap.recycle();
                        processing.set(false);
                    });
        } catch (Exception e) {
            processing.set(false);
            android.util.Log.w("NearbyRadar", "Frame processing error", e);
        } finally {
            if (image != null) image.close();
        }
    }

    private static Bitmap extractBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        if (planes.length == 0) return null;
        Image.Plane p = planes[0];
        int rowStride = p.getRowStride();
        int pixelStride = p.getPixelStride();
        if (pixelStride != 4 || rowStride <= 0) return null;
        int width = image.getWidth(), height = image.getHeight();
        int rowBytes = width * 4;
        if (rowStride < rowBytes) return null;
        ByteBuffer input = p.getBuffer();
        byte[] packed = new byte[rowBytes * height];
        for (int y=0; y<height; y++) {
            int offset = y*rowStride;
            if (offset + rowBytes > input.limit()) return null;
            input.position(offset);
            input.get(packed, y*rowBytes, rowBytes);
        }
        Bitmap frame = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        frame.copyPixelsFromBuffer(ByteBuffer.wrap(packed));
        return frame;
    }

    private static String normalize(String input) {
        if (input == null) return "";
        return input.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .trim().replaceAll("\\s+", " ");
    }

    private void showMatches(Text recognized, int bitmapWidth, int bitmapHeight) {
        if (shuttingDown || radarLayer == null) return;
        List<RectF> found = new ArrayList<>();
        for (Text.TextBlock block: recognized.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                String label = normalize(line.getText());
                if (label.contains(target)) {
                    Rect bounds = line.getBoundingBox();
                    if (bounds != null) found.add(new RectF(bounds));
                }
            }
        }
        mainHandler.post(() -> {
            if (shuttingDown || radarLayer == null) return;
            radarLayer.update(found, bitmapWidth, bitmapHeight);
            if (bubble != null && !paused) bubble.setText("RADAR: " + found.size());
        });
    }

    private void stopCapture() {
        if (reader != null) {
            reader.setOnImageAvailableListener(null, null);
        }
        if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay=null; }
        if (reader != null) { reader.close(); reader=null; }
        if (projection != null) {
            MediaProjection p = projection;
            projection = null;
            p.stop();
        }
    }

    @Override public void onDestroy() {
        shuttingDown = true;
        stopCapture();
        if (radarLayer != null) {
            try { windows.removeView(radarLayer); } catch (Exception ignored) {}
            radarLayer = null;
        }
        if (bubble != null) {
            try { windows.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
        if (recognizer != null) recognizer.close();
        if (worker != null) worker.quitSafely();
        super.onDestroy();
    }
}
