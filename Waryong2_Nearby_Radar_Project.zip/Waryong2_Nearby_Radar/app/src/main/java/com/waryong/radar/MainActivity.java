package com.waryong.radar;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE = 720;
    private static final int REQUEST_OVERLAY = 721;
    private static final int REQUEST_NOTIFY = 722;
    private EditText targetField;
    private MediaProjectionManager projectionManager;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        buildUi();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView label(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setPadding(0, dp(5), 0, dp(5));
        return view;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(13, 23, 36));
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(22), dp(34), dp(22), dp(24));
        scroll.addView(panel);

        TextView title = label("WARYONG2 SCANNER", 25, Color.rgb(84, 230, 169), true);
        panel.addView(title);
        panel.addView(label("Nearby on-screen target highlighter", 15, Color.WHITE, false));
        panel.addView(label("\u0627\u0644\u0623\u062f\u0627\u0629 \u0628\u062a\u062d\u062f\u062f \u0627\u0644\u0623\u0633\u0645\u0627\u0621 \u0627\u0644\u0644\u064a \u0638\u0627\u0647\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0634\u0627\u0634\u0629 \u0628\u0633. \u0645\u0634 \u0631\u0627\u062f\u0627\u0631 \u0644\u0644\u0648\u062d\u0648\u0634 \u0627\u0644\u0645\u062e\u0641\u064a\u0629 \u0623\u0648 \u0627\u0644\u0644\u064a \u0648\u0631\u0627\u0643.", 14, Color.rgb(192, 201, 213), false));

        panel.addView(label("Target label (Latin letters)", 14, Color.WHITE, true));
        targetField = new EditText(this);
        targetField.setSingleLine(true);
        targetField.setTextColor(Color.WHITE);
        targetField.setHintTextColor(Color.rgb(147, 162, 183));
        targetField.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(84, 230, 169)));
        targetField.setInputType(InputType.TYPE_CLASS_TEXT);
        targetField.setHint("Metin / Metin of Darkness");
        targetField.setText(getPreferences(0).getString("target", "Metin"));
        panel.addView(targetField);

        panel.addView(label("Examples: Metin, Orc, Black Wind, Tiger. Use the word visible above the enemy. Latin text works best; Arabic names are not reliably supported by this OCR model.", 13, Color.rgb(181, 192, 207), false));
        Button start = new Button(this);
        start.setText("START ON-SCREEN SCANNER");
        start.setAllCaps(false);
        start.setTextColor(Color.rgb(9, 27, 27));
        start.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(84, 230, 169)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(56));
        lp.topMargin = dp(20);
        panel.addView(start, lp);
        start.setOnClickListener(v -> startFlow());

        Button stop = new Button(this);
        stop.setText("STOP SCANNER");
        stop.setAllCaps(false);
        stop.setTextColor(Color.WHITE);
        stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(65, 83, 102)));
        panel.addView(stop, new LinearLayout.LayoutParams(-1, dp(52)));
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, RadarService.class);
            intent.setAction(RadarService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "Scanner stopped", Toast.LENGTH_SHORT).show();
        });

        panel.addView(label("HOW TO USE", 16, Color.rgb(84, 230, 169), true));
        panel.addView(label("1. Choose the name shown above the monster.\n2. Allow display-over-apps.\n3. Approve Android screen capture.\n4. Open Waryong2. Recognized labels get a green highlight.\n5. Tap the small RADAR bubble to pause; long-press it to stop.", 14, Color.WHITE, false));
        panel.addView(label("NO root, Shizuku, network permissions or game-file modifications. Android may hide protected game content from screen capture. Detection accuracy depends on readable enemy labels.", 13, Color.rgb(180, 190, 205), false));
        setContentView(scroll);
    }

    private void startFlow() {
        String target = targetField.getText().toString().trim();
        if (target.isEmpty()) { targetField.setError("Enter the target name"); return; }
        getPreferences(0).edit().putString("target", target).apply();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Enable Display over other apps for the scanner", Toast.LENGTH_LONG).show();
            Intent request = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(request, REQUEST_OVERLAY);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFY);
            return;
        }
        requestCapture();
    }

    private void requestCapture() {
        if (projectionManager == null) {
            Toast.makeText(this, "Screen projection unavailable on this phone", Toast.LENGTH_LONG).show();
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_NOTIFY) requestCapture(); // notifications optional
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) startFlow();
            else Toast.makeText(this, "Overlay permission needed", Toast.LENGTH_LONG).show();
        } else if (requestCode == REQUEST_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "Screen capture permission declined", Toast.LENGTH_LONG).show();
                return;
            }
            Intent i = new Intent(this, RadarService.class);
            i.setAction(RadarService.ACTION_START);
            i.putExtra(RadarService.EXTRA_RESULT, resultCode);
            i.putExtra(RadarService.EXTRA_DATA, data);
            i.putExtra(RadarService.EXTRA_TARGET, targetField.getText().toString().trim());
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "Scanner running. Open Waryong2.", Toast.LENGTH_LONG).show();
            moveTaskToBack(true);
        }
    }
}
