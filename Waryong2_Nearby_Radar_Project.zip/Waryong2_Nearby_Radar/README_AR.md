# Waryong2 Nearby Scanner — Android project (beta)

## What it does

The app puts a transparent highlight over **recognized visible Latin-script enemy names** from the screen, e.g. `Metin`, `Orc`, `Tiger`. It has a movable floating indicator, and captures screen frames ~every 1.4 seconds using Android MediaProjection. OCR uses the locally bundled Google ML Kit Latin Text Recognition library. No Internet permission is requested. The app does **not** read/modify Waryong2 files, code or memory.

**IMPORTANT:** It does NOT reveal entities outside the rendered screen, monsters behind the player, or hidden spawn points. It does not call the game's nativeMetinNear function. Shizuku doesn't remove Android process isolation. Recognition of Arabic-script text is not supported by the included Latin model. Waryong2 may block overlays or screen capture (e.g. FLAG_SECURE), and game policies may restrict overlay utilities. This project is a prototype and has not been tested in-game.

## Create APK (GitHub Actions)

1. Create a GitHub repository for the project. Upload **the extracted project files** preserving the folders (`app/`, `.github/workflows/`, etc.).
2. Open the repository -> Actions -> `Build installable APK` -> `Run workflow` (or just push files to the main branch).
3. Wait for the GitHub Action to complete. Open that workflow run's **Artifacts** section and download `Waryong2-Nearby-Scanner-APK.zip`.
4. Extract it; inside is `app-debug.apk`. Install it on your Android phone.

Requires a GitHub account and internet access to build. No PC, Root, Shizuku, credit card or Play Store publication required.

## Build locally with Android Studio / Android SDK

- JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.6.1, Gradle 8.9.
- Run `gradle :app:assembleDebug` at repository root.
- Output `app/build/outputs/apk/debug/app-debug.apk`.

## Use on Android

1. Open "Waryong2 Nearby Scanner".
2. Enter the visible name; `Metin` is the default. Uses case-insensitive partial matches.
3. Tap **START ON-SCREEN SCANNER**.
4. Grant "Display over other apps" and Android screen recording/capture permissions.
5. Open Waryong2; highlights will appear where matching readable names are rendered.
6. Tap floating `RADAR` button to pause/resume; press and hold for ~0.75 seconds to stop. You can also return to the app and tap STOP.

## Privacy and security

The app requests only overlay, screen projection, foreground-service and notification permissions. It does not request Internet access. Screen frames are processed on-device and discarded immediately after recognition. It does not collect credentials or game network traffic.

## Status

**Source-only, uncompiled/unverified.** This environment does not include the Android SDK or a network connection for Android dependencies, so no finished installable APK or device test was possible here. The included GitHub workflow is intended to build it, but a successful build and in-game behavior need to be verified on a real Android device.

---

## شرح مختصر بالعربي

دي **نسخة تجريبية لكشف أسماء الأهداف الظاهرة على الشاشة** وليست رادارًا حقيقيًا للوحوش البعيدة أو المخفية. اكتب `Metin` وشغّل التصوير والنافذة العائمة؛ المفروض التطبيق يحدد أسماء Metin المقروءة لو اللعبة تسمح بتصويرها. جودة الكشف تعتمد على حجم ولغة الخط. المشروع لا يحتاج Root أو Shizuku، ولا يعدل ملفات اللعبة.

**الملف ده مصدر للتطبيق مش APK جاهز.** استخدم GitHub Actions حسب الخطوات فوق لإنتاج APK؛ لم يتم التحقق من نجاح البناء أو تشغيله داخل اللعبة في البيئة الحالية.
